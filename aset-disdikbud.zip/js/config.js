// js/config.js
const ADMIN_KODE = "admin889";
